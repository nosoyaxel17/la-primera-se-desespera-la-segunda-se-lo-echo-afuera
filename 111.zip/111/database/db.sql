-- Crear base de datos
CREATE DATABASE IF NOT EXISTS draftosaurus_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE draftosaurus_db;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuario (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(120) NOT NULL UNIQUE,
  hash_password VARCHAR(255) NOT NULL,
  estado ENUM('activo','bloqueado') DEFAULT 'activo',
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabla de tablero
CREATE TABLE IF NOT EXISTS tablero (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(80) NOT NULL,
  ancho INT NOT NULL,
  alto INT NOT NULL
);

-- Tabla de celdas
CREATE TABLE IF NOT EXISTS celda (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  tablero_id BIGINT NOT NULL,
  fila INT NOT NULL,
  columna INT NOT NULL,
  tipo ENUM('normal','bosque','rio','montana') DEFAULT 'normal',
  UNIQUE(tablero_id, fila, columna),
  FOREIGN KEY (tablero_id) REFERENCES tablero(id)
);

-- Tabla de especies de dinosaurios
CREATE TABLE IF NOT EXISTS especie_dinosaurio (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(80) NOT NULL UNIQUE,
  categoria ENUM('carnivoro','herbivoro','otro') NOT NULL
);

-- Tabla de partidas
CREATE TABLE IF NOT EXISTS partida (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  usuario_id BIGINT NOT NULL,
  tablero_id BIGINT NOT NULL,
  estado ENUM('en_curso','finalizada') DEFAULT 'en_curso',
  config_json JSON NULL,
  creada_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  actualizada_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuario(id),
  FOREIGN KEY (tablero_id) REFERENCES tablero(id)
);

-- Tabla de inventario de partida
CREATE TABLE IF NOT EXISTS inventario_partida (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  partida_id BIGINT NOT NULL,
  especie_id BIGINT NOT NULL,
  cantidad INT NOT NULL CHECK (cantidad >= 0),
  UNIQUE(partida_id, especie_id),
  FOREIGN KEY (partida_id) REFERENCES partida(id),
  FOREIGN KEY (especie_id) REFERENCES especie_dinosaurio(id)
);

-- Tabla de colocaciones
CREATE TABLE IF NOT EXISTS colocacion (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  partida_id BIGINT NOT NULL,
  celda_id BIGINT NOT NULL,
  especie_id BIGINT NOT NULL,
  colocada_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(partida_id, celda_id),
  FOREIGN KEY (partida_id) REFERENCES partida(id),
  FOREIGN KEY (celda_id) REFERENCES celda(id),
  FOREIGN KEY (especie_id) REFERENCES especie_dinosaurio(id)
);

-- Insertar datos de ejemplo

-- Insertar tableros de ejemplo
INSERT INTO tablero (nombre, ancho, alto) VALUES 
('Tablero Básico', 5, 5),
('Tablero Grande', 8, 8);

-- Insertar celdas para el tablero básico
INSERT INTO celda (tablero_id, fila, columna, tipo) VALUES
(1, 0, 0, 'normal'), (1, 0, 1, 'bosque'), (1, 0, 2, 'normal'), (1, 0, 3, 'rio'), (1, 0, 4, 'normal'),
(1, 1, 0, 'bosque'), (1, 1, 1, 'normal'), (1, 1, 2, 'montana'), (1, 1, 3, 'normal'), (1, 1, 4, 'bosque'),
(1, 2, 0, 'normal'), (1, 2, 1, 'rio'), (1, 2, 2, 'normal'), (1, 2, 3, 'rio'), (1, 2, 4, 'normal'),
(1, 3, 0, 'montana'), (1, 3, 1, 'normal'), (1, 3, 2, 'bosque'), (1, 3, 3, 'normal'), (1, 3, 4, 'montana'),
(1, 4, 0, 'normal'), (1, 4, 1, 'bosque'), (1, 4, 2, 'normal'), (1, 4, 3, 'montana'), (1, 4, 4, 'normal');

-- Insertar especies de dinosaurios
INSERT INTO especie_dinosaurio (nombre, categoria) VALUES
('Tyrannosaurus Rex', 'carnivoro'),
('Velociraptor', 'carnivoro'),
('Triceratops', 'herbivoro'),
('Brachiosaurus', 'herbivoro'),
('Stegosaurus', 'herbivoro'),
('Pteranodon', 'otro'),
('Diplodocus', 'herbivoro'),
('Allosaurus', 'carnivoro');

-- Crear un usuario de prueba (contraseña: 123456)
-- La contraseña hasheada es para '123456'
INSERT INTO usuario (email, hash_password, estado) VALUES
('test@draftosaurus.com', '$2y$10$YourHashedPasswordHere', 'activo');

-- Nota: Para generar el hash real, usa PHP:
-- echo password_hash('123456', PASSWORD_BCRYPT);