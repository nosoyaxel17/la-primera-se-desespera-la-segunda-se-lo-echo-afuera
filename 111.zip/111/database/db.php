<?php
// config.php - Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Contraseña por defecto en XAMPP
define('DB_NAME', 'draftosaurus_db');

// Configuración de email (usando mail() de PHP)
define('SMTP_FROM', 'noreply@draftosaurus.local');
define('SITE_NAME', 'Draftosaurus');
define('SITE_URL', 'http://localhost/draftosaurus'); // Ajusta según tu carpeta en XAMPP

// Zona horaria
date_default_timezone_set('America/Montevideo');

// Inicio de sesión
session_start();

// Función de conexión
function getConnection() {
    try {
        $conn = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $conn;
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

// Función para generar código de verificación
function generateVerificationCode() {
    return str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
}

// Función para enviar email (simulado para desarrollo local)
function sendVerificationEmail($email, $code) {
    // En producción, usa PHPMailer o similar
    // Para desarrollo local, guardamos el código en sesión
    $_SESSION['verification_code'] = $code;
    $_SESSION['verification_email'] = $email;
    $_SESSION['code_expires'] = time() + 600; // Expira en 10 minutos
    
    // En desarrollo, mostramos el código (quitar en producción)
    return true;
}

// Función para validar email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Función para hash de contraseña
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

// Función para verificar contraseña
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}
?>