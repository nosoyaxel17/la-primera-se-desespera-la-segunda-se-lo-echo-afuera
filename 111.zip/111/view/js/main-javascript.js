// Sistema de gestión de salas y menú principal integrado
class GameManager {
    constructor() {
        this.user = this.loadUser();
        this.room = null;
        this.isAdmin = false;
        this.init();
    }

    init() {
        this.checkAuth();
        this.setupEventListeners();
        this.showWelcome();
    }

    loadUser() {
        const stored = sessionStorage.getItem('user');
        return stored ? JSON.parse(stored) : {
            id: `user_${Date.now()}`,
            name: `Jugador${Math.floor(Math.random() * 1000)}`,
            age: Math.floor(Math.random() * 50) + 18,
            type: 'guest'
        };
    }

    checkAuth() {
        const userNameElement = document.getElementById('userName');
        if (userNameElement) {
            userNameElement.textContent = this.user.name;
        }
    }

    showWelcome() {
        if (!sessionStorage.getItem('welcomed')) {
            this.showNotification(`¡Bienvenido ${this.user.name}!`, 'success');
            sessionStorage.setItem('welcomed', 'true');
        }
    }

    setupEventListeners() {
        // Event listeners para los botones del menú principal
        window.startQuickGame = () => this.startQuickGame();
        window.createRoom = () => this.createRoom();
        window.joinRoom = () => this.showJoinRoomModal();
        window.logout = () => this.logout();
    }

    // RF4: Partida rápida
    startQuickGame() {
        this.showNotification('Buscando partida...', 'info');
        
        setTimeout(() => {
            this.room = {
                code: this.generateRoomCode(),
                maxPlayers: Math.floor(Math.random() * 4) + 2,
                players: [this.user],
                isQuickMatch: true,
                adminId: this.user.id
            };
            
            this.isAdmin = true;
            this.showNotification('¡Partida encontrada!', 'success');
            setTimeout(() => this.goToGame(), 1500);
        }, 2000);
    }

    // RF4, RF7: Crear sala - Redirigir a sala de espera
    createRoom() {
        // Guardar datos del usuario y redirigir a sala de espera
        sessionStorage.setItem('user', JSON.stringify(this.user));
        
        // Mostrar notificación y redirigir
        this.showNotification('Redirigiendo a crear sala...', 'info');
        
        setTimeout(() => {
            window.location.href = 'waitingRoom.html';
        }, 1000);
    }

    // RF4, RF8: Unirse a sala
    showJoinRoomModal() {
        const modal = this.createModal('Unirse a Sala', `
            <div class="mb-3">
                <label class="form-label">Código de Sala</label>
                <input type="text" id="joinCodeInput" class="form-control" maxlength="10" placeholder="Ingresa el código">
                <div class="form-text">Código de 4-10 caracteres alfanuméricos</div>
            </div>
        `, [
            { text: 'Cancelar', class: 'btn-secondary', action: 'close' },
            { text: 'Unirse', class: 'btn-success', action: () => this.joinRoom() }
        ]);
        
        modal.show();

        // Validación en tiempo real
        const input = document.getElementById('joinCodeInput');
        const joinBtn = modal.element.querySelector('.btn-success');
        
        input.addEventListener('input', () => {
            const code = input.value.trim();
            const isValid = /^[A-Za-z0-9]{4,10}$/.test(code);
            
            if (isValid) {
                input.classList.remove('is-invalid');
                input.classList.add('is-valid');
                joinBtn.disabled = false;
            } else {
                input.classList.remove('is-valid');
                if (code.length > 0) {
                    input.classList.add('is-invalid');
                }
                joinBtn.disabled = true;
            }
        });
    }

    joinRoom() {
        const code = document.getElementById('joinCodeInput').value.trim().toUpperCase();
        
        if (!this.validateRoomCode(code)) {
            this.showNotification('Código inválido (4-10 caracteres alfanuméricos)', 'error');
            return;
        }

        // Simular búsqueda de sala
        const foundRoom = this.findRoom(code);
        if (!foundRoom) {
            this.showNotification('Sala no encontrada o llena', 'error');
            return;
        }

        // RF6: Asignar rol de usuario
        this.room = foundRoom;
        this.room.players.push(this.user);
        this.isAdmin = false;
        
        this.closeCurrentModal();
        this.showNotification('¡Te has unido a la sala!', 'success');
        
        // Guardar datos y mostrar sala de espera
        setTimeout(() => {
            this.showJoinedWaitingRoom();
        }, 1500);
    }

    showJoinedWaitingRoom() {
        // Crear datos de juego para sala ya existente
        const gameData = {
            user: this.user,
            isAdmin: this.isAdmin,
            room: this.room
        };
        
        sessionStorage.setItem('gameData', JSON.stringify(gameData));
        this.showWaitingRoom();
    }

    // Sistema de sala de espera integrado
    showWaitingRoom() {
        const waitingHTML = `
            <div class="waiting-room-overlay">
                <div class="waiting-room-card">
                    <div class="text-center mb-4">
                        <h3><i class="fas fa-clock text-primary"></i> Sala de Espera</h3>
                        <p class="mb-0">Código: <strong class="room-code-display">${this.room.code}</strong> 
                            <button onclick="gameManager.copyCode()" class="btn btn-sm btn-outline-primary ms-2">
                                <i class="fas fa-copy"></i>
                            </button>
                        </p>
                    </div>
                    
                    <div class="players-info text-center mb-3">
                        <span class="badge bg-primary fs-6" id="playersBadge">${this.room.players.length}/${this.room.maxPlayers} jugadores</span>
                    </div>
                    
                    <div id="playersList" class="players-list mb-4"></div>
                    
                    <div class="room-controls text-center">
                        ${this.isAdmin ? `
                            <button onclick="gameManager.startGameFromWaiting()" 
                                    id="startGameBtn"
                                    class="btn btn-success btn-lg me-2" 
                                    ${this.room.players.length < 2 ? 'disabled' : ''}>
                                <i class="fas fa-play"></i> Iniciar Partida
                            </button>
                        ` : '<p class="text-muted mb-3">Esperando que el administrador inicie la partida...</p>'}
                        
                        <button onclick="gameManager.leaveWaitingRoom()" class="btn btn-outline-danger">
                            <i class="fas fa-sign-out-alt"></i> Salir de la Sala
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', waitingHTML);
        this.updatePlayersList();
        
        if (this.isAdmin) {
            this.simulatePlayersJoining();
        }
    }

    updatePlayersList() {
        const listElement = document.getElementById('playersList');
        const badge = document.getElementById('playersBadge');
        
        if (!listElement) return;

        if (badge) {
            badge.textContent = `${this.room.players.length}/${this.room.maxPlayers} jugadores`;
        }

        listElement.innerHTML = this.room.players.map((player, index) => `
            <div class="player-item d-flex justify-content-between align-items-center mb-2 p-2 bg-light rounded">
                <div class="d-flex align-items-center">
                    <i class="fas fa-${player.id === this.room.adminId ? 'crown text-warning' : 'user text-primary'} me-2"></i>
                    <strong>${player.name}</strong>
                    ${player.id === this.room.adminId ? '<span class="badge bg-warning text-dark ms-2">Admin</span>' : ''}
                </div>
                <div>
                    <span class="badge bg-secondary">${player.age} años</span>
                </div>
            </div>
        `).join('');
    }

    // RF9: Iniciar partida (solo admin)
    startGameFromWaiting() {
        if (!this.isAdmin || this.room.players.length < 2) {
            this.showNotification('No se puede iniciar la partida', 'error');
            return;
        }
        
        this.showNotification('Iniciando partida...', 'success');
        setTimeout(() => this.goToGame(), 1500);
    }

    goToGame() {
        // RF11: Determinar primer jugador (más joven)
        const youngestPlayer = this.room.players.reduce((youngest, current) => 
            current.age < youngest.age ? current : youngest
        );

        // Guardar datos completos para el juego
        const gameData = {
            room: {
                ...this.room,
                firstPlayer: youngestPlayer
            },
            isAdmin: this.isAdmin,
            user: this.user
        };
        
        sessionStorage.setItem('gameData', JSON.stringify(gameData));
        window.location.href = 'gameboard.html';
    }

    // RF7: Abandonar sala
    leaveWaitingRoom() {
        if (confirm('¿Salir de la sala?')) {
            document.querySelector('.waiting-room-overlay')?.remove();
            sessionStorage.removeItem('gameData');
            this.room = null;
            this.isAdmin = false;
        }
    }

    copyCode() {
        if (this.room && this.room.code) {
            navigator.clipboard.writeText(this.room.code).then(() => {
                this.showNotification('Código copiado al portapapeles', 'success');
            }).catch(() => {
                // Fallback para navegadores sin soporte de clipboard
                const textArea = document.createElement('textarea');
                textArea.value = this.room.code;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                this.showNotification('Código copiado', 'success');
            });
        }
    }

    // Utilidades
    validateRoomCode(code) {
        return /^[A-Z0-9]{4,10}$/.test(code);
    }

    generateRoomCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < 6; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    findRoom(code) {
        // Simular salas existentes con más realismo
        const mockRooms = [
            { 
                code: 'DINO123', 
                maxPlayers: 4, 
                players: [{ id: 'host1', name: 'DinoMaster', age: 25 }],
                adminId: 'host1'
            },
            { 
                code: 'GAME456', 
                maxPlayers: 3, 
                players: [
                    { id: 'host2', name: 'RexHunter', age: 30 },
                    { id: 'player2', name: 'TriKing', age: 22 }
                ],
                adminId: 'host2'
            },
            { 
                code: 'TEST789', 
                maxPlayers: 5, 
                players: [{ id: 'host3', name: 'DinoFan', age: 28 }],
                adminId: 'host3'
            }
        ];
        
        const foundRoom = mockRooms.find(room => room.code === code);
        
        // Verificar si la sala existe y no está llena
        if (foundRoom && foundRoom.players.length < foundRoom.maxPlayers) {
            return { ...foundRoom };
        }
        
        return null;
    }

    simulatePlayersJoining() {
        if (!this.isAdmin || !this.room) return;
        
        const botNames = ['DinoFan', 'RexHunter', 'TriKing', 'StegoBoss', 'DracoBeast'];
        let joinIndex = 0;
        
        const joinTimer = setInterval(() => {
            if (this.room.players.length >= this.room.maxPlayers || 
                !document.querySelector('.waiting-room-overlay')) {
                clearInterval(joinTimer);
                return;
            }
            
            // 70% de probabilidad de que se una un jugador
            if (Math.random() > 0.3 && joinIndex < botNames.length) {
                const bot = {
                    id: `bot_${Date.now()}_${joinIndex}`,
                    name: botNames[joinIndex] + Math.floor(Math.random() * 100),
                    age: Math.floor(Math.random() * 40) + 18,
                    type: 'bot'
                };
                
                this.room.players.push(bot);
                this.updatePlayersList();
                this.showNotification(`${bot.name} se unió a la sala`, 'info');
                
                // Habilitar botón de inicio si hay suficientes jugadores
                const startBtn = document.getElementById('startGameBtn');
                if (startBtn && this.room.players.length >= 2) {
                    startBtn.disabled = false;
                }
                
                joinIndex++;
            }
        }, 3000);
        
        // Limpiar el timer después de un tiempo máximo
        setTimeout(() => clearInterval(joinTimer), 30000);
    }

    createModal(title, content, buttons) {
        const modal = document.createElement('div');
        modal.className = 'custom-modal-overlay';
        modal.innerHTML = `
            <div class="custom-modal">
                <div class="modal-header">
                    <h4 class="modal-title">${title}</h4>
                </div>
                <div class="modal-body">${content}</div>
                <div class="modal-footer">
                    ${buttons.map(btn => `
                        <button class="btn ${btn.class}" data-action="${btn.action === 'close' ? 'close' : 'custom'}">
                            ${btn.text}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
        
        // Event listener para los botones
        modal.addEventListener('click', (e) => {
            if (e.target.classList.contains('custom-modal-overlay')) {
                this.closeCurrentModal();
            }
            
            const btn = e.target.closest('button');
            if (btn) {
                const action = btn.dataset.action;
                if (action === 'close') {
                    this.closeCurrentModal();
                } else {
                    const buttonConfig = buttons.find(b => b.text === btn.textContent);
                    if (buttonConfig && typeof buttonConfig.action === 'function') {
                        buttonConfig.action();
                    }
                }
            }
        });
        
        document.body.appendChild(modal);
        
        return { 
            show: () => {
                modal.style.display = 'flex';
                // Focus en el primer input si existe
                const firstInput = modal.querySelector('input');
                if (firstInput) {
                    setTimeout(() => firstInput.focus(), 100);
                }
            },
            element: modal
        };
    }

    closeCurrentModal() {
        const modal = document.querySelector('.custom-modal-overlay');
        if (modal) {
            modal.style.opacity = '0';
            setTimeout(() => modal.remove(), 300);
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas fa-${this.getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        document.body.appendChild(notification);
        
        // Animación de entrada
        setTimeout(() => notification.classList.add('show'), 10);
        
        // Auto-remove después de 5 segundos
        setTimeout(() => {
            if (notification.parentElement) {
                notification.classList.remove('show');
                setTimeout(() => {
                    if (notification.parentElement) {
                        notification.remove();
                    }
                }, 300);
            }
        }, 5000);
    }

    getNotificationIcon(type) {
        const icons = { 
            success: 'check-circle', 
            error: 'exclamation-circle', 
            info: 'info-circle',
            warning: 'exclamation-triangle'
        };
        return icons[type] || 'info-circle';
    }

    logout() {
        if (confirm('¿Cerrar sesión y volver al inicio?')) {
            sessionStorage.clear();
            window.location.href = 'login.html';
        }
    }
}

// CSS dinámico mejorado para modales y notificaciones
const styles = `
    .custom-modal-overlay {
        position: fixed; top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.5); display: flex; align-items: center;
        justify-content: center; z-index: 9999; opacity: 1;
        transition: opacity 0.3s ease;
    }
    .custom-modal {
        background: white; border-radius: 15px; overflow: hidden;
        max-width: 500px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        transform: scale(1); transition: transform 0.3s ease;
    }
    .custom-modal-overlay:not(.show) .custom-modal {
        transform: scale(0.9);
    }
    .modal-header {
        padding: 20px; background: #f8f9fa; border-bottom: 1px solid #dee2e6;
    }
    .modal-title {
        margin: 0; color: #495057; font-weight: 600;
    }
    .modal-body {
        padding: 20px;
    }
    .modal-footer { 
        display: flex; gap: 10px; padding: 15px 20px; 
        background: #f8f9fa; justify-content: flex-end;
    }
    
    .waiting-room-overlay {
        position: fixed; top: 0; left: 0; right: 0; bottom: 0;
        background: linear-gradient(135deg, rgba(0,0,0,0.8), rgba(0,50,100,0.8));
        display: flex; align-items: center; justify-content: center; z-index: 9998;
    }
    .waiting-room-card {
        background: white; padding: 30px; border-radius: 20px;
        max-width: 600px; width: 90%; box-shadow: 0 25px 80px rgba(0,0,0,0.3);
        animation: slideIn 0.5s ease-out;
    }
    @keyframes slideIn {
        from { opacity: 0; transform: translateY(-30px) scale(0.95); }
        to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .room-code-display {
        font-family: 'Courier New', monospace; font-size: 1.1em;
        background: #e3f2fd; padding: 6px 12px; border-radius: 8px;
        border: 1px solid #2196f3; color: #1976d2; font-weight: bold;
    }
    .players-list { 
        max-height: 300px; overflow-y: auto; 
        border: 1px solid #dee2e6; border-radius: 10px; padding: 10px;
        background: #fafafa;
    }
    .player-item {
        transition: all 0.2s ease;
    }
    .player-item:hover {
        transform: translateX(5px);
    }
    
    .notification {
        position: fixed; top: 20px; right: 20px; min-width: 300px;
        padding: 15px 20px; border-radius: 12px; background: white;
        box-shadow: 0 8px 32px rgba(0,0,0,0.12); display: flex; align-items: center; 
        gap: 12px; z-index: 10000; opacity: 0; transform: translateX(100%);
        transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }
    .notification.show { 
        opacity: 1; transform: translateX(0); 
    }
    .notification-close {
        background: none; border: none; margin-left: auto;
        color: #999; cursor: pointer; padding: 4px;
        border-radius: 4px; transition: all 0.2s ease;
    }
    .notification-close:hover {
        background: #f0f0f0; color: #666;
    }
    .notification-success { 
        border-left: 4px solid #28a745; 
    }
    .notification-success i { color: #28a745; }
    .notification-error { 
        border-left: 4px solid #dc3545; 
    }
    .notification-error i { color: #dc3545; }
    .notification-info { 
        border-left: 4px solid #17a2b8; 
    }
    .notification-info i { color: #17a2b8; }
    .notification-warning {
        border-left: 4px solid #ffc107;
    }
    .notification-warning i { color: #f57c00; }
    
    /* Responsive improvements */
    @media (max-width: 768px) {
        .waiting-room-card {
            padding: 20px; margin: 10px;
        }
        .notification {
            right: 10px; left: 10px; min-width: auto;
        }
        .custom-modal {
            margin: 20px;
        }
    }
`;

// Inyectar estilos solo una vez
if (!document.querySelector('#game-manager-styles')) {
    const styleElement = document.createElement('style');
    styleElement.id = 'game-manager-styles';
    styleElement.textContent = styles;
    document.head.appendChild(styleElement);
}

// Inicializar cuando se carga la página
document.addEventListener('DOMContentLoaded', () => {
    console.log('Inicializando Game Manager...');
    window.gameManager = new GameManager();
});

// Guardar referencia global
window.GameManager = GameManager;