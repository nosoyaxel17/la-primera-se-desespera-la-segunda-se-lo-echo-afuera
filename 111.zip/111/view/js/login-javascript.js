// Login Script
document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            // Basic validation
            if (!email || !password) {
                showAlert('Por favor completa todos los campos', 'warning');
                return;
            }
            
            // Simulate login
            showAlert('Iniciando sesión...', 'info');
            
            setTimeout(() => {
                // Store user session
                sessionStorage.setItem('user', JSON.stringify({
                    email: email,
                    name: email.split('@')[0],
                    loginType: 'email'
                }));
                
                // Redirect to main menu
                window.location.href = 'index.html';
            }, 1500);
        });
    }
});

// Google Login
function loginWithGoogle() {
    showAlert('Conectando con Google...', 'info');
    
    // Simulate Google OAuth
    setTimeout(() => {
        sessionStorage.setItem('user', JSON.stringify({
            email: 'usuario@gmail.com',
            name: 'Usuario Google',
            loginType: 'google'
        }));
        
        window.location.href = 'index.html';
    }, 1500);
}

// Guest Login
function loginAsGuest() {
    showAlert('Entrando como invitado...', 'info');
    
    setTimeout(() => {
        sessionStorage.setItem('user', JSON.stringify({
            email: 'guest@draftosaurus.com',
            name: 'Invitado' + Math.floor(Math.random() * 1000),
            loginType: 'guest'
        }));
        
        window.location.href = 'index.html';
    }, 1000);
}

// Alert System
function showAlert(message, type) {
    // Remove existing alerts
    const existingAlert = document.querySelector('.custom-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // Create alert
    const alert = document.createElement('div');
    alert.className = `custom-alert alert-${type}`;
    alert.innerHTML = `
        <i class="fas fa-${getIconByType(type)}"></i>
        <span>${message}</span>
    `;
    
    // Add to page
    document.body.appendChild(alert);
    
    // Animate
    setTimeout(() => {
        alert.classList.add('show');
    }, 10);
    
    // Remove after 3 seconds
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => {
            alert.remove();
        }, 300);
    }, 3000);
}

function getIconByType(type) {
    const icons = {
        'success': 'check-circle',
        'error': 'exclamation-circle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Add custom alert styles dynamically
const alertStyles = `
    .custom-alert {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 10px;
        background: white;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 9999;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
    }
    
    .custom-alert.show {
        opacity: 1;
        transform: translateX(0);
    }
    
    .alert-success { border-left: 4px solid #28a745; }
    .alert-success i { color: #28a745; }
    
    .alert-error { border-left: 4px solid #dc3545; }
    .alert-error i { color: #dc3545; }
    
    .alert-warning { border-left: 4px solid #ffc107; }
    .alert-warning i { color: #ffc107; }
    
    .alert-info { border-left: 4px solid #17a2b8; }
    .alert-info i { color: #17a2b8; }
`;

// Inject styles
const styleSheet = document.createElement('style');
styleSheet.textContent = alertStyles;
document.head.appendChild(styleSheet);