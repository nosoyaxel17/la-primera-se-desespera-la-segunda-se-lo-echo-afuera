// gameboard.js - Sistema de juego Draftosaurus completamente funcional

class DraftosaurusGame {
    constructor() {
        // Cargar datos del juego
        this.gameData = JSON.parse(sessionStorage.getItem('gameData'));
        if (!this.gameData) {
            window.location.href = 'index.html';
            return;
        }

        // Configuración del juego
        this.dinosaurTypes = ['diplodocus', 'triceratops', 'trex', 'stegosaurus', 'brachiosaurus', 'parasaurolophus'];
        this.diceConfig = {
            // RNF57: Probabilidades específicas del dado
            bosque: { probability: 16.67, icon: 'fa-tree', text: 'Árboles Comunes', areas: ['bosque'] },
            llanura: { probability: 16.67, icon: 'fa-seedling', text: 'Manzanos', areas: ['llanura'] },
            banos: { probability: 16.67, icon: 'fa-restroom', text: 'Baños', sides: ['derecha'] },
            cafeteria: { probability: 25, icon: 'fa-coffee', text: 'Cafeterías', sides: ['izquierda'] },
            vacio: { probability: 16.67, icon: 'fa-box-open', text: 'Recinto Vacío', requireEmpty: true },
            'no-trex': { probability: 8.33, icon: 'fa-ban', text: 'Sin T-Rex', forbiddenType: 'trex' }
        };

        // Estado del juego
        this.state = {
            // Configuración del tablero
            selectedBoard: null,
            selectedDirection: null,
            
            // Control de partida
            round: 1,
            turn: 1,
            maxRounds: 2,
            maxTurns: 6,
            
            // Control de turnos
            currentPlayerIndex: 0,
            players: [...this.gameData.room.players],
            isMyTurn: false,
            
            // Estado del turno actual
            currentDice: null,
            placedThisTurn: false,
            timeLeft: 60,
            timer: null,
            
            // Dinosaurios
            allPlayerHands: new Map(), // Manos de todos los jugadores
            myBoard: {}, // Mi tablero personal
            
            // Puntuaciones
            scores: new Map()
        };

        this.init();
    }

    init() {
        console.log('Iniciando juego con datos:', this.gameData);
        this.setupGlobalFunctions();
        this.determineFirstPlayer();
        this.showBoardSelector();
        this.setupDragAndDrop();
    }

    setupGlobalFunctions() {
        // Funciones globales para el HTML
        window.selectBoard = (board) => this.selectBoard(board);
        window.confirmBoardSelection = () => this.confirmBoard();
        window.selectDirection = (dir) => this.selectDirection(dir);
        window.confirmDirection = () => this.confirmDirection();
        window.rollDice = () => this.rollDice();
        window.confirmPlacement = () => this.confirmPlacement();
    }

    // RF11: Determinar primer jugador por edad
    determineFirstPlayer() {
        console.log('Determinando primer jugador...');
        
        // Encontrar el jugador más joven
        let youngest = this.state.players[0];
        for (const player of this.state.players) {
            if (player.age < youngest.age) {
                youngest = player;
            } else if (player.age === youngest.age) {
                // En caso de empate, aleatorio entre los empatados
                if (Math.random() > 0.5) {
                    youngest = player;
                }
            }
        }

        // Encontrar el índice del jugador más joven
        this.state.currentPlayerIndex = this.state.players.findIndex(p => p.id === youngest.id);
        console.log(`Primer jugador: ${youngest.name} (${youngest.age} años)`);
        
        this.updateTurnStatus();
    }

    // RF24: Selector de tablero
    showBoardSelector() {
        document.getElementById('boardSelector').classList.remove('hidden');
    }

    selectBoard(boardType) {
        this.state.selectedBoard = boardType;
        document.querySelectorAll('.board-option').forEach(opt => opt.classList.remove('selected'));
        event.currentTarget.classList.add('selected');
    }

    confirmBoard() {
        if (!this.state.selectedBoard) {
            alert('Selecciona un tablero');
            return;
        }
        
        // Aplicar el tablero seleccionado
        document.getElementById('gameBoard').className = `board-wrapper ${this.state.selectedBoard}-board`;
        document.getElementById('boardSelector').classList.add('hidden');
        
        // RF21: Solo el administrador/primer jugador elige dirección
        if (this.gameData.isAdmin) {
            this.showDirectionSelector();
        } else {
            this.startGame();
        }
    }

    showDirectionSelector() {
        document.getElementById('directionSelector').classList.remove('hidden');
    }

    selectDirection(direction) {
        this.state.selectedDirection = direction;
        document.querySelectorAll('.direction-option').forEach(opt => opt.classList.remove('selected'));
        event.currentTarget.classList.add('selected');
        document.getElementById('confirmDirectionBtn').disabled = false;
    }

    confirmDirection() {
        if (!this.state.selectedDirection) {
            alert('Selecciona una dirección');
            return;
        }
        
        document.getElementById('directionSelector').classList.add('hidden');
        this.startGame();
    }

    // RF17: Iniciar el juego
    startGame() {
        console.log('Iniciando partida...');
        this.initializePlayerHands();
        this.updateUI();
        this.startTurn();
    }

    // RF17: Cada jugador recibe 6 dinosaurios al azar
    initializePlayerHands() {
        console.log('Inicializando manos de los jugadores...');
        
        for (const player of this.state.players) {
            const hand = [];
            for (let i = 0; i < 6; i++) {
                hand.push({
                    id: `dino-${player.id}-${Date.now()}-${i}`,
                    type: this.dinosaurTypes[Math.floor(Math.random() * this.dinosaurTypes.length)],
                    ownerId: player.id
                });
            }
            this.state.allPlayerHands.set(player.id, hand);
        }
        
        console.log('Manos inicializadas:', this.state.allPlayerHands);
        this.renderMyHand();
    }

    renderMyHand() {
        const myHand = this.state.allPlayerHands.get(this.gameData.user.id) || [];
        const handElement = document.getElementById('dinosaurHand');
        
        handElement.innerHTML = myHand.map(dino => `
            <div class="dinosaur-card" draggable="true" data-dino-id="${dino.id}" data-dino-type="${dino.type}">
                <i class="fas fa-dragon dino-${dino.type}"></i>
                <div class="dino-name">${dino.type}</div>
            </div>
        `).join('');
        
        document.getElementById('dinoCount').textContent = myHand.length;
        this.setupDragAndDrop();
    }

    startTurn() {
        console.log(`Iniciando turno ${this.state.turn} de la ronda ${this.state.round}`);
        
        this.state.placedThisTurn = false;
        this.state.currentDice = null;
        this.updateTurnStatus();
        this.startTimer();
        
        // Habilitar/deshabilitar controles según el turno
        const rollBtn = document.getElementById('rollDiceBtn');
        const confirmBtn = document.getElementById('confirmBtn');
        
        if (this.state.isMyTurn) {
            rollBtn.disabled = false;
            rollBtn.style.display = 'block';
        } else {
            rollBtn.disabled = true;
        }
        
        confirmBtn.style.display = 'none';
    }

    updateTurnStatus() {
        const currentPlayer = this.state.players[this.state.currentPlayerIndex];
        this.state.isMyTurn = (currentPlayer.id === this.gameData.user.id);
        
        const indicator = document.getElementById('turnIndicator');
        if (this.state.isMyTurn) {
            indicator.innerHTML = '<h5 class="text-success">¡Tu turno! Lanza el dado</h5>';
        } else {
            indicator.innerHTML = `<h5 class="text-info">Turno de ${currentPlayer.name}</h5>`;
        }
    }

    // RF12, RF13: Sistema de dado
    rollDice() {
        if (!this.state.isMyTurn) {
            alert('No es tu turno');
            return;
        }

        // Generar resultado del dado usando probabilidades RNF57
        const random = Math.random() * 100;
        let cumulative = 0;
        
        for (const [face, config] of Object.entries(this.diceConfig)) {
            cumulative += config.probability;
            if (random <= cumulative) {
                this.state.currentDice = face;
                break;
            }
        }
        
        console.log('Dado lanzado:', this.state.currentDice);
        this.updateDiceDisplay();
        this.highlightValidZones();
        
        document.getElementById('rollDiceBtn').disabled = true;
    }

    updateDiceDisplay() {
        const config = this.diceConfig[this.state.currentDice];
        const display = document.getElementById('diceDisplay');
        display.innerHTML = `<i class="fas ${config.icon}"></i> ${config.text}`;
        display.classList.add('dice-rolled');
    }

    // Sistema Drag & Drop
    setupDragAndDrop() {
        // Setup para dinosaurios arrastrables
        document.querySelectorAll('.dinosaur-card').forEach(card => {
            card.ondragstart = (e) => this.handleDragStart(e);
            card.ondragend = (e) => this.handleDragEnd(e);
        });
        
        // Setup para zonas de drop
        document.querySelectorAll('.drop-zone').forEach(zone => {
            zone.ondragover = (e) => e.preventDefault();
            zone.ondrop = (e) => this.handleDrop(e);
            zone.ondragenter = (e) => this.handleDragEnter(e);
            zone.ondragleave = (e) => this.handleDragLeave(e);
        });
    }

    handleDragStart(e) {
        if (!this.state.isMyTurn || !this.state.currentDice) {
            e.preventDefault();
            return;
        }
        
        e.dataTransfer.setData('text/plain', e.target.dataset.dinoId);
        e.target.classList.add('dragging');
        this.highlightValidZones();
    }

    handleDragEnd(e) {
        e.target.classList.remove('dragging');
        this.clearHighlights();
    }

    handleDragEnter(e) {
        if (e.target.classList.contains('valid-zone')) {
            e.target.classList.add('drag-over');
        }
    }

    handleDragLeave(e) {
        e.target.classList.remove('drag-over');
    }

    handleDrop(e) {
        e.preventDefault();
        
        if (this.state.placedThisTurn) {
            alert('Ya colocaste un dinosaurio este turno');
            return;
        }
        
        const dinoId = e.dataTransfer.getData('text/plain');
        const dinoCard = document.querySelector(`[data-dino-id="${dinoId}"]`);
        const zone = e.target.closest('.drop-zone');
        
        if (!zone) return;
        
        if (this.isValidPlacement(zone, dinoCard.dataset.dinoType)) {
            this.placeDinosaur(zone, dinoCard);
        } else {
            // RNF25: Mensaje de error con indicación
            this.showPlacementError(zone);
        }
        
        this.clearHighlights();
    }

    // RF48, RNF48: Validación de colocación según dado
    isValidPlacement(zone, dinoType) {
        // Si la zona está ocupada, no es válida
        if (zone.classList.contains('occupied')) {
            return false;
        }
        
        // El río siempre es válido (RF20)
        if (zone.dataset.zone === 'river') {
            return true;
        }
        
        // Si no hay dado lanzado, permitir colocación libre
        if (!this.state.currentDice) {
            return true;
        }
        
        const diceConfig = this.diceConfig[this.state.currentDice];
        const zoneArea = zone.dataset.area;
        const zoneSide = zone.dataset.side;
        const zoneType = zone.dataset.zone;
        
        // Validaciones específicas por cara del dado
        switch (this.state.currentDice) {
            case 'bosque': // RF34: Árboles Comunes
                return zoneArea === 'bosque';
                
            case 'llanura': // RF35: Manzanos  
                return zoneArea === 'llanura';
                
            case 'banos': // RF36: Baños (lado derecho)
                return zoneSide === 'derecha';
                
            case 'cafeteria': // RF37: Cafeterías (lado izquierdo)
                return zoneSide === 'izquierda';
                
            case 'vacio': // RF38: Recinto vacío
                return !zone.classList.contains('occupied');
                
            case 'no-trex': // RF39: Sin T-Rex
                return !this.hasTraxInZone(zoneType);
                
            default:
                return true;
        }
    }

    hasTraxInZone(zoneType) {
        const zoneData = this.state.myBoard[zoneType];
        return zoneData && zoneData.some(dino => dino.type === 'trex');
    }

    placeDinosaur(zone, dinoCard) {
        const dinoType = dinoCard.dataset.dinoType;
        const dinoId = dinoCard.dataset.dinoId;
        const zoneType = zone.dataset.zone;
        const slot = zone.dataset.slot;
        
        // Crear elemento visual en el tablero
        zone.innerHTML = `<div class="placed-dino"><i class="fas fa-dragon dino-${dinoType}"></i></div>`;
        zone.classList.add('occupied');
        zone.dataset.dinoType = dinoType;
        
        // Actualizar estado del tablero
        if (!this.state.myBoard[zoneType]) {
            this.state.myBoard[zoneType] = [];
        }
        
        this.state.myBoard[zoneType].push({
            type: dinoType,
            id: dinoId,
            slot: slot
        });
        
        // Remover dinosaurio de la mano
        const myHand = this.state.allPlayerHands.get(this.gameData.user.id);
        const dinoIndex = myHand.findIndex(d => d.id === dinoId);
        if (dinoIndex > -1) {
            myHand.splice(dinoIndex, 1);
        }
        
        // Actualizar interfaz
        dinoCard.remove();
        document.getElementById('dinoCount').textContent = myHand.length;
        
        this.state.placedThisTurn = true;
        document.getElementById('confirmBtn').style.display = 'block';
        
        console.log('Dinosaurio colocado:', { zoneType, dinoType, boardState: this.state.myBoard });
    }

    showPlacementError(zone) {
        const config = this.diceConfig[this.state.currentDice];
        let message = `No puedes colocar aquí. `;
        
        switch (this.state.currentDice) {
            case 'bosque':
                message += 'Debes colocar en el área de Árboles Comunes (Bosque)';
                break;
            case 'llanura':
                message += 'Debes colocar en el área de Manzanos (Llanura)';
                break;
            case 'banos':
                message += 'Debes colocar en el lado de Baños (derecha)';
                break;
            case 'cafeteria':
                message += 'Debes colocar en el lado de Cafeterías (izquierda)';
                break;
            case 'vacio':
                message += 'Debes colocar en un recinto vacío';
                break;
            case 'no-trex':
                message += 'Debes colocar en un recinto sin T-Rex';
                break;
        }
        
        message += ', o puedes colocar en el río.';
        alert(message);
    }

    highlightValidZones() {
        document.querySelectorAll('.drop-zone').forEach(zone => {
            const isValid = this.isValidPlacement(zone, 'test');
            zone.classList.add(isValid ? 'valid-zone' : 'invalid-zone');
        });
    }

    clearHighlights() {
        document.querySelectorAll('.drop-zone').forEach(zone => {
            zone.classList.remove('valid-zone', 'invalid-zone', 'drag-over');
        });
    }

    // RF14, RF15: Confirmar colocación
    confirmPlacement() {
        if (!this.state.placedThisTurn) {
            alert('Debes colocar un dinosaurio antes de confirmar');
            return;
        }
        
        console.log('Colocación confirmada');
        this.nextTurn();
    }

    // RF16: Control de turnos y rondas
    nextTurn() {
        // RF18: Pasar dinosaurios al siguiente jugador
        this.passDinosaurs();
        
        this.state.turn++;
        
        // Verificar fin de ronda
        if (this.state.turn > this.state.maxTurns) {
            this.endRound();
            return;
        }
        
        // Cambiar al siguiente jugador
        this.nextPlayer();
        this.startTurn();
    }

    // RF18: Sistema de paso de dinosaurios
    passDinosaurs() {
        console.log('Pasando dinosaurios...');
        
        // Crear nuevo mapa con las manos rotadas
        const newHands = new Map();
        const playerIds = this.state.players.map(p => p.id);
        
        for (let i = 0; i < playerIds.length; i++) {
            const currentId = playerIds[i];
            let nextIndex;
            
            if (this.state.selectedDirection === 'clockwise') {
                nextIndex = (i + 1) % playerIds.length;
            } else {
                nextIndex = (i - 1 + playerIds.length) % playerIds.length;
            }
            
            const nextId = playerIds[nextIndex];
            const currentHand = this.state.allPlayerHands.get(currentId) || [];
            
            newHands.set(nextId, [...currentHand]);
        }
        
        this.state.allPlayerHands = newHands;
        this.renderMyHand();
        
        console.log('Dinosaurios pasados. Nueva mano:', this.state.allPlayerHands.get(this.gameData.user.id));
    }

    nextPlayer() {
        if (this.state.selectedDirection === 'clockwise') {
            this.state.currentPlayerIndex = (this.state.currentPlayerIndex + 1) % this.state.players.length;
        } else {
            this.state.currentPlayerIndex = (this.state.currentPlayerIndex - 1 + this.state.players.length) % this.state.players.length;
        }
        
        console.log('Siguiente jugador:', this.state.players[this.state.currentPlayerIndex].name);
    }

    endRound() {
        console.log(`Fin de ronda ${this.state.round}`);
        
        if (this.state.round < this.state.maxRounds) {
            // Iniciar siguiente ronda
            this.state.round++;
            this.state.turn = 1;
            alert(`¡Fin de Ronda ${this.state.round - 1}! Iniciando Ronda ${this.state.round}...`);
            
            // RF17: Generar nuevos dinosaurios para la segunda ronda
            this.initializePlayerHands();
            this.startTurn();
        } else {
            this.endGame();
        }
    }

    // RF22: Timer de 60 segundos
    startTimer() {
        this.state.timeLeft = 60;
        clearInterval(this.state.timer);
        
        this.state.timer = setInterval(() => {
            this.state.timeLeft--;
            this.updateTimerDisplay();
            
            if (this.state.timeLeft <= 0) {
                this.handleTimeout();
            }
        }, 1000);
    }

    updateTimerDisplay() {
        const display = document.getElementById('timerDisplay');
        display.textContent = this.state.timeLeft;
        
        if (this.state.timeLeft <= 10) {
            display.className = 'timer-display danger';
        } else if (this.state.timeLeft <= 30) {
            display.className = 'timer-display warning';
        } else {
            display.className = 'timer-display';
        }
    }

    // RF22: Timeout - colocar automáticamente en río
    handleTimeout() {
        clearInterval(this.state.timer);
        
        if (!this.state.placedThisTurn && this.state.isMyTurn) {
            const myHand = this.state.allPlayerHands.get(this.gameData.user.id);
            
            if (myHand && myHand.length > 0) {
                const riverZone = document.getElementById('river');
                const randomDino = myHand[0];
                
                // Simular colocación en río
                this.placeDinosaur(riverZone, {
                    dataset: {
                        dinoType: randomDino.type,
                        dinoId: randomDino.id
                    },
                    remove: () => {} // Función vacía ya que no hay elemento DOM
                });
                
                alert('¡Tiempo agotado! Dinosaurio colocado automáticamente en el río.');
            }
        }
        
        this.nextTurn();
    }

    updateUI() {
        document.getElementById('currentRound').textContent = this.state.round;
        document.getElementById('currentTurn').textContent = this.state.turn;
        this.updateTurnStatus();
    }

    // RF41-RF43: Fin del juego y cálculo de puntuaciones
    endGame() {
        clearInterval(this.state.timer);
        
        console.log('Calculando puntuaciones finales...');
        const scoreCalculator = new ScoreCalculator(this.state.myBoard);
        const finalScore = scoreCalculator.calculateTotal();
        
        // RF42, RF43: Mostrar resultados
        const resultsModal = this.createResultsModal(finalScore, scoreCalculator);
        document.body.appendChild(resultsModal);
        
        const modal = new bootstrap.Modal(resultsModal);
        modal.show();
    }

    createResultsModal(totalScore, calculator) {
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h4 class="modal-title">¡Partida Finalizada!</h4>
                    </div>
                    <div class="modal-body">
                        <div class="text-center mb-4">
                            <h2 class="display-4">${totalScore} puntos</h2>
                            <p class="lead">Tu puntuación final</p>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Desglose de Puntuación:</h5>
                                <table class="table table-sm">
                                    <tr><td>Bosque de la Semejanza</td><td>${calculator.calculateForest()} pts</td></tr>
                                    <tr><td>Prado de la Diferencia</td><td>${calculator.calculatePrairie()} pts</td></tr>
                                    <tr><td>Pradera del Amor</td><td>${calculator.calculateLove()} pts</td></tr>
                                    <tr><td>Trío Frondoso</td><td>${calculator.calculateTrio()} pts</td></tr>
                                    <tr><td>Rey de la Selva</td><td>${calculator.calculateKing()} pts</td></tr>
                                    <tr><td>Isla Solitaria</td><td>${calculator.calculateIsland()} pts</td></tr>
                                    <tr><td>Río</td><td>${calculator.calculateRiver()} pts</td></tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h5>Tu Tablero Final:</h5>
                                <div class="board-summary">
                                    ${this.getBoardSummary()}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" onclick="window.location.href='index.html'">
                            Volver al Menú
                        </button>
                        <button class="btn btn-success" onclick="window.location.reload()">
                            Jugar de Nuevo
                        </button>
                    </div>
                </div>
            </div>
        `;
        return modal;
    }

    getBoardSummary() {
        let summary = '';
        for (const [zone, dinos] of Object.entries(this.state.myBoard)) {
            if (dinos.length > 0) {
                summary += `<p><strong>${this.getZoneName(zone)}:</strong> `;
                summary += dinos.map(d => d.type).join(', ');
                summary += '</p>';
            }
        }
        return summary || '<p>No hay dinosaurios colocados</p>';
    }

    getZoneName(zoneKey) {
        const names = {
            'forest-same': 'Bosque de la Semejanza',
            'prairie-diff': 'Prado de la Diferencia', 
            'love-prairie': 'Pradera del Amor',
            'trio': 'Trío Frondoso',
            'king': 'Rey de la Selva',
            'island': 'Isla Solitaria',
            'river': 'Río'
        };
        return names[zoneKey] || zoneKey;
    }
}

// Calculadora de puntuaciones según reglas específicas
class ScoreCalculator {
    constructor(board) {
        this.board = board;
    }

    calculateTotal() {
        return this.calculateForest() + this.calculatePrairie() + 
               this.calculateLove() + this.calculateTrio() + 
               this.calculateKing() + this.calculateIsland() + 
               this.calculateRiver();
    }

    // RF27: Bosque de la Semejanza - dinosaurios del mismo tipo
    calculateForest() {
        const forest = this.board['forest-same'] || [];
        if (forest.length === 0) return 0;
        
        // Verificar que todos sean del mismo tipo
        const firstType = forest[0].type;
        const sameTypeCount = forest.filter(d => d.type === firstType).length;
        
        if (sameTypeCount !== forest.length) return 0; // No todos son iguales
        
        const scoreTable = [0, 2, 4, 8, 12, 18, 24];
        return scoreTable[sameTypeCount] || 0;
    }

    // RF28: Prado de la Diferencia - dinosaurios de tipos diferentes
    calculatePrairie() {
        const prairie = this.board['prairie-diff'] || [];
        const uniqueTypes = [...new Set(prairie.map(d => d.type))];
        
        // Verificar que no haya tipos repetidos
        if (uniqueTypes.length !== prairie.length) return 0;
        
        const scoreTable = [0, 1, 3, 6, 10, 15, 21];
        return scoreTable[uniqueTypes.length] || 0;
    }

    // RF29: Pradera del Amor - pares del mismo tipo
    calculateLove() {
        const love = this.board['love-prairie'] || [];
        const typeCounts = {};
        
        for (const dino of love) {
            typeCounts[dino.type] = (typeCounts[dino.type] || 0) + 1;
        }
        
        let pairs = 0;
        for (const count of Object.values(typeCounts)) {
            pairs += Math.floor(count / 2);
        }
        
        return pairs * 5;
    }

    // RF30: Trío Frondoso - exactamente 3 dinosaurios
    calculateTrio() {
        const trio = this.board['trio'] || [];
        return trio.length === 3 ? 7 : 0;
    }

    // RF31: Rey de la Selva - tener más dinosaurios de ese tipo que otros
    calculateKing() {
        const king = this.board['king'] || [];
        if (king.length === 0) return 0;
        
        // Simplificado: si hay un dinosaurio, otorga puntos
        // En una implementación completa, compararía con otros jugadores
        return king.length > 0 ? 7 : 0;
    }

    // RF32: Isla Solitaria - único dinosaurio de su tipo en todo el parque
    calculateIsland() {
        const island = this.board['island'] || [];
        if (island.length !== 1) return 0;
        
        const islandType = island[0].type;
        let totalCount = 0;
        
        // Contar en todas las zonas
        for (const zone of Object.values(this.board)) {
            totalCount += zone.filter(d => d.type === islandType).length;
        }
        
        return totalCount === 1 ? 7 : 0;
    }

    // RF20: Río - 1 punto por dinosaurio
    calculateRiver() {
        const river = this.board['river'] || [];
        return river.length;
    }
}

// Estilos dinámicos mejorados
const gameStyles = `
    .valid-zone { 
        background-color: rgba(40, 167, 69, 0.3) !important; 
        border: 2px solid #28a745 !important;
        box-shadow: 0 0 10px rgba(40, 167, 69, 0.5);
    }
    .invalid-zone { 
        background-color: rgba(220, 53, 69, 0.3) !important; 
        border: 2px solid #dc3545 !important;
        box-shadow: 0 0 10px rgba(220, 53, 69, 0.5);
    }
    .drag-over {
        transform: scale(1.05);
        transition: transform 0.2s;
    }
    .placed-dino {
        display: flex; 
        align-items: center; 
        justify-content: center;
        width: 100%; 
        height: 100%; 
        font-size: 1.5em;
        animation: placeAnimation 0.3s ease-in;
    }
    @keyframes placeAnimation {
        0% { transform: scale(0); opacity: 0; }
        100% { transform: scale(1); opacity: 1; }
    }
    .dinosaur-card {
        background: linear-gradient(145deg, #f8f9fa, #e9ecef); 
        border: 2px solid #dee2e6; 
        border-radius: 12px;
        padding: 15px; 
        margin: 8px; 
        text-align: center; 
        cursor: grab;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .dinosaur-card:hover { 
        transform: translateY(-3px) scale(1.05); 
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        border-color: #007bff;
    }
    .dinosaur-card.dragging { 
        opacity: 0.7; 
        transform: rotate(5deg);
    }
    .dinosaur-card .fas {
        font-size: 2em;
        margin-bottom: 8px;
        display: block;
    }
    .dino-name {
        font-size: 0.9em;
        font-weight: bold;
        text-transform: capitalize;
    }
    
    .dino-diplodocus { color: #8B4513; }
    .dino-triceratops { color: #32CD32; }
    .dino-trex { color: #DC143C; }
    .dino-stegosaurus { color: #FF8C00; }
    .dino-brachiosaurus { color: #4169E1; }
    .dino-parasaurolophus { color: #9932CC; }
    
    .timer-display {
        font-size: 2em;
        font-weight: bold;
        text-align: center;
        padding: 10px;
        border-radius: 50%;
        width: 80px;
        height: 80px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #e9ecef;
        margin: 0 auto;
    }
    .timer-display.warning { 
        color: #ff6b35; 
        background: #fff3cd;
        border: 2px solid #ffeaa7;
    }
    .timer-display.danger { 
        color: #dc3545; 
        background: #f8d7da;
        border: 2px solid #f5c6cb;
        animation: pulse 1s infinite; 
    }
    
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
    }
    
    .dice-display {
        font-size: 1.2em;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
        text-align: center;
        margin: 10px 0;
    }
    
    .dice-rolled {
        background: linear-gradient(145deg, #28a745, #20c997);
        color: white;
        animation: diceRoll 0.5s ease-out;
    }
    
    @keyframes diceRoll {
        0% { transform: rotateY(0deg) rotateX(0deg); }
        25% { transform: rotateY(90deg) rotateX(90deg); }
        50% { transform: rotateY(180deg) rotateX(180deg); }
        75% { transform: rotateY(270deg) rotateX(270deg); }
        100% { transform: rotateY(360deg) rotateX(360deg); }
    }
`;

// Inyectar estilos
document.head.insertAdjacentHTML('beforeend', `<style>${gameStyles}</style>`);

// Inicializar el juego cuando la página cargue
document.addEventListener('DOMContentLoaded', () => {
    console.log('Inicializando Draftosaurus...');
    window.game = new DraftosaurusGame();
});