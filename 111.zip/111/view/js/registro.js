
        // Variables globales
        let timerInterval = null;
        let timeRemaining = 600; // 10 minutos
        
        // Formulario de registro
        document.getElementById('registerForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (password !== confirmPassword) {
                showAlert('Las contraseñas no coinciden', 'danger');
                return;
            }
            
            if (password.length < 6) {
                showAlert('La contraseña debe tener al menos 6 caracteres', 'danger');
                return;
            }
            
            // Mostrar spinner
            document.getElementById('registerBtnText').style.display = 'none';
            document.getElementById('registerBtnSpinner').style.display = 'inline-block';
            
            try {
                const formData = new FormData();
                formData.append('action', 'register');
                formData.append('email', email);
                formData.append('password', password);
                formData.append('confirmPassword', confirmPassword);
                
                const response = await fetch('register.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showAlert('¡Código enviado! Revisa tu email', 'success');
                    
                    // Mostrar código en desarrollo
                    if (data.debug_code) {
                        showAlert(`DESARROLLO: Tu código es ${data.debug_code}`, 'info');
                    }
                    
                    // Ocultar formulario y mostrar verificación
                    document.getElementById('registerForm').style.display = 'none';
                    document.getElementById('verificationSection').style.display = 'block';
                    
                    // Iniciar temporizador
                    startTimer();
                } else {
                    showAlert(data.message || 'Error al registrar', 'danger');
                }
            } catch (error) {
                showAlert('Error de conexión', 'danger');
                console.error(error);
            } finally {
                document.getElementById('registerBtnText').style.display = 'inline';
                document.getElementById('registerBtnSpinner').style.display = 'none';
            }
        });
        
        // Formulario de verificación
        document.getElementById('verificationForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const code = document.getElementById('verificationCode').value;
            
            if (code.length !== 6) {
                showAlert('El código debe tener 6 dígitos', 'danger');
                return;
            }
            
            document.getElementById('verifyBtnText').style.display = 'none';
            document.getElementById('verifyBtnSpinner').style.display = 'inline-block';
            
            try {
                const formData = new FormData();
                formData.append('action', 'verify');
                formData.append('code', code);
                
                const response = await fetch('register.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showAlert('¡Registro exitoso! Redirigiendo...', 'success');
                    setTimeout(() => {
                        window.location.href = data.redirect || 'index.html';
                    }, 2000);
                } else {
                    showAlert(data.message || 'Código incorrecto', 'danger');
                }
            } catch (error) {
                showAlert('Error de conexión', 'danger');
            } finally {
                document.getElementById('verifyBtnText').style.display = 'inline';
                document.getElementById('verifyBtnSpinner').style.display = 'none';
            }
        });
        
        // Medidor de fuerza de contraseña
        document.getElementById('password').addEventListener('input', (e) => {
            const password = e.target.value;
            const strength = document.getElementById('passwordStrength');
            
            if (password.length === 0) {
                strength.style.display = 'none';
                return;
            }
            
            strength.style.display = 'block';
            
            if (password.length < 6) {
                strength.className = 'password-strength strength-weak';
            } else if (password.length < 10 || !/[A-Z]/.test(password) || !/[0-9]/.test(password)) {
                strength.className = 'password-strength strength-medium';
            } else {
                strength.className = 'password-strength strength-strong';
            }
        });
        
   
                