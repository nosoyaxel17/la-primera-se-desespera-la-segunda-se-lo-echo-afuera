// waitingRoom.js - Sala de espera integrada con GameManager

class WaitingRoom {
    constructor() {
        this.userData = null;
        this.roomData = null;
        this.isAdmin = false;
        this.players = [];
        this.maxPlayers = 5;
        this.joinTimer = null;
        this.init();
    }

    init() {
        this.loadUserData();
        this.setupEventListeners();
        this.checkRoomStatus();
    }

    loadUserData() {
        // Cargar datos del usuario desde sessionStorage
        const userData = sessionStorage.getItem('user');
        if (!userData) {
            // Si no hay datos de usuario, crear uno temporal
            this.userData = {
                id: `user_${Date.now()}`,
                name: `Jugador${Math.floor(Math.random() * 1000)}`,
                age: Math.floor(Math.random() * 50) + 18,
                type: 'guest'
            };
            sessionStorage.setItem('user', JSON.stringify(this.userData));
        } else {
            this.userData = JSON.parse(userData);
        }
        
        console.log('Usuario cargado:', this.userData);
        this.updateUIWithUserData();
    }

    updateUIWithUserData() {
        // Pre-llenar campos con datos del usuario
        const playerNameInput = document.getElementById('playerName');
        const playerAgeInput = document.getElementById('playerAge');
        
        if (playerNameInput && this.userData.name) {
            playerNameInput.value = this.userData.name;
        }
        
        if (playerAgeInput && this.userData.age) {
            playerAgeInput.value = this.userData.age;
        }
    }

    checkRoomStatus() {
        // Verificar si ya estamos en una sala (viniendo desde GameManager)
        const gameData = sessionStorage.getItem('gameData');
        if (gameData) {
            const data = JSON.parse(gameData);
            if (data.room && data.room.code) {
                // Ya estamos en una sala, mostrar interfaz de espera
                this.roomData = data.room;
                this.isAdmin = data.isAdmin;
                this.players = data.room.players || [];
                this.maxPlayers = data.room.maxPlayers || 5;
                this.showWaitingInterface();
                this.updatePlayersDisplay();
                return;
            }
        }
        
        // Si no estamos en una sala, generar código sugerido
        this.generateSuggestedCode();
    }

    generateSuggestedCode() {
        const suggestedCode = this.generateRoomCode();
        const roomCodeInput = document.getElementById('roomCode');
        if (roomCodeInput) {
            roomCodeInput.value = suggestedCode;
            this.validateRoomCode();
        }
    }

    setupEventListeners() {
        // RF7: Validación de código en tiempo real
        const roomCodeInput = document.getElementById('roomCode');
        if (roomCodeInput) {
            roomCodeInput.addEventListener('input', this.validateRoomCode.bind(this));
        }

        // Validaciones en tiempo real para todos los campos
        ['playerCount', 'playerName', 'playerAge'].forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.addEventListener('input', () => this.checkFormValidity());
                field.addEventListener('change', () => this.checkFormValidity());
            }
        });

        // Configurar funciones globales
        window.createRoom = () => this.createRoom();
        window.startGame = () => this.startGame();
        window.goBack = () => this.goBack();
        window.leaveRoom = () => this.leaveRoom();
    }

    generateRoomCode() {
        // RF7: Generar código alfanumérico de 4-10 caracteres
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < 6; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    validateRoomCode() {
        const roomCodeInput = document.getElementById('roomCode');
        const createBtn = document.getElementById('createRoomBtn');
        
        if (!roomCodeInput || !createBtn) return;
        
        const roomCode = roomCodeInput.value;
        
        // RF7: Validación 4-10 caracteres alfanuméricos
        const isValid = /^[A-Za-z0-9]{4,10}$/.test(roomCode);
        
        if (roomCode.length === 0) {
            roomCodeInput.classList.remove('is-invalid', 'is-valid');
            createBtn.disabled = true;
        } else if (isValid) {
            roomCodeInput.classList.remove('is-invalid');
            roomCodeInput.classList.add('is-valid');
            this.checkFormValidity();
        } else {
            roomCodeInput.classList.remove('is-valid');
            roomCodeInput.classList.add('is-invalid');
            createBtn.disabled = true;
        }
    }

    checkFormValidity() {
        const roomCode = document.getElementById('roomCode')?.value.trim() || '';
        const playerCount = document.getElementById('playerCount')?.value || '';
        const playerName = document.getElementById('playerName')?.value.trim() || '';
        const playerAge = document.getElementById('playerAge')?.value || '';
        const createBtn = document.getElementById('createRoomBtn');

        if (!createBtn) return;

        const isValid = roomCode && /^[A-Za-z0-9]{4,10}$/.test(roomCode) && 
                       playerCount && playerName && playerAge;
        
        createBtn.disabled = !isValid;
    }

    createRoom() {
        // Validar todos los campos
        const roomCode = document.getElementById('roomCode')?.value.trim().toUpperCase() || '';
        const playerCount = document.getElementById('playerCount')?.value || '';
        const playerName = document.getElementById('playerName')?.value.trim() || '';
        const playerAge = parseInt(document.getElementById('playerAge')?.value || '0');

        // Validaciones según requisitos
        if (!this.validateFields(roomCode, playerCount, playerName, playerAge)) {
            return;
        }

        // RF5: Asignar rol de administrador al creador
        this.isAdmin = true;
        
        // Actualizar datos del usuario
        this.userData.name = playerName;
        this.userData.age = playerAge;
        this.userData.isAdmin = true;
        sessionStorage.setItem('user', JSON.stringify(this.userData));

        // RF10: Crear sala con configuración del administrador
        this.roomData = {
            code: roomCode,
            maxPlayers: parseInt(playerCount),
            adminId: this.userData.id,
            createdAt: new Date(),
            players: [{...this.userData}],
            status: 'waiting',
            gameStarted: false
        };

        this.players = [...this.roomData.players];
        this.maxPlayers = this.roomData.maxPlayers;

        // Guardar datos de la sala para integración con GameManager
        const gameData = {
            user: this.userData,
            isAdmin: this.isAdmin,
            room: this.roomData
        };
        sessionStorage.setItem('gameData', JSON.stringify(gameData));

        // Mostrar interfaz de sala creada
        this.showWaitingInterface();
        this.updatePlayersDisplay();
        this.showStatus(`Sala ${roomCode} creada exitosamente. Esperando jugadores...`, 'success');

        // Simular la llegada de jugadores
        this.simulatePlayersJoining();
    }

    validateFields(roomCode, playerCount, playerName, playerAge) {
        // RF7: Validación de código de sala
        if (!/^[A-Za-z0-9]{4,10}$/.test(roomCode)) {
            this.showStatus('El código de sala debe tener entre 4 y 10 caracteres alfanuméricos', 'error');
            return false;
        }

        // RF10: Validación de cantidad de jugadores (2-5)
        if (!playerCount || playerCount < 2 || playerCount > 5) {
            this.showStatus('Selecciona un número válido de jugadores (2-5)', 'error');
            return false;
        }

        if (!playerName || playerName.length < 2) {
            this.showStatus('Ingresa un nombre válido (mínimo 2 caracteres)', 'error');
            return false;
        }

        if (!playerAge || playerAge < 5 || playerAge > 100) {
            this.showStatus('Ingresa una edad válida (5-100)', 'error');
            return false;
        }

        return true;
    }

    showWaitingInterface() {
        // Ocultar formulario y mostrar interfaz de espera
        const elementsToHide = ['createRoomBtn'];
        const elementsToShow = ['startGameBtn', 'leaveRoomBtn', 'playersListContainer'];

        elementsToHide.forEach(id => {
            const element = document.getElementById(id);
            if (element) element.style.display = 'none';
        });

        elementsToShow.forEach(id => {
            const element = document.getElementById(id);
            if (element) element.style.display = 'block';
        });

        // Deshabilitar campos del formulario
        ['roomCode', 'playerCount', 'playerName', 'playerAge'].forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) field.disabled = true;
        });

        // Mostrar información de la sala
        this.displayRoomInfo();
    }

    displayRoomInfo() {
        const roomCodeDisplay = document.querySelector('.room-code-display');
        if (roomCodeDisplay && this.roomData) {
            roomCodeDisplay.textContent = `Código: ${this.roomData.code}`;
        }
    }

    simulatePlayersJoining() {
        if (!this.isAdmin) return;
        
        // Nombres simulados para testing
        const botNames = ['Ana García', 'Carlos López', 'María Rodriguez', 'Pedro Martínez', 'Sofia Torres'];
        let joinedCount = 0;
        const maxToJoin = Math.min(this.maxPlayers - 1, 3);

        this.joinTimer = setInterval(() => {
            if (joinedCount >= maxToJoin || this.players.length >= this.maxPlayers) {
                clearInterval(this.joinTimer);
                return;
            }

            // 60% de probabilidad de que se una un jugador cada 3 segundos
            if (Math.random() > 0.4) {
                const botPlayer = {
                    id: `bot_${Date.now()}_${Math.random()}`,
                    name: botNames[joinedCount % botNames.length],
                    age: 15 + Math.floor(Math.random() * 35),
                    type: 'bot',
                    isAdmin: false
                };

                this.addPlayer(botPlayer);
                joinedCount++;
            }
        }, 3000);
    }

    addPlayer(player) {
        this.players.push(player);
        this.roomData.players = [...this.players];
        
        // Actualizar sessionStorage
        const gameData = JSON.parse(sessionStorage.getItem('gameData') || '{}');
        gameData.room = this.roomData;
        sessionStorage.setItem('gameData', JSON.stringify(gameData));
        
        this.updatePlayersDisplay();
        this.showStatus(`${player.name} se ha unido a la sala`, 'info');

        // RF9: Habilitar botón de inicio si hay al menos 2 jugadores
        const startBtn = document.getElementById('startGameBtn');
        if (startBtn && this.players.length >= 2) {
            startBtn.disabled = false;
        }
    }

    updatePlayersDisplay() {
        const playersList = document.getElementById('playersList');
        const playerCountBadge = document.getElementById('playerCountBadge');
        
        if (playerCountBadge) {
            playerCountBadge.textContent = `${this.players.length}/${this.maxPlayers}`;
        }
        
        if (playersList) {
            playersList.innerHTML = this.players.map(player => `
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-${player.isAdmin ? 'crown' : 'user'} ${player.isAdmin ? 'text-warning' : 'text-primary'}"></i>
                        <strong class="ms-2">${player.name}</strong>
                        ${player.isAdmin ? '<span class="badge bg-warning text-dark ms-2">Admin</span>' : ''}
                    </div>
                    <div>
                        <span class="badge bg-secondary">${player.age} años</span>
                    </div>
                </li>
            `).join('');
        }
    }

    startGame() {
        // RF9: Solo el administrador puede iniciar
        if (!this.isAdmin) {
            this.showStatus('Solo el administrador puede iniciar la partida', 'error');
            return;
        }

        if (this.players.length < 2) {
            this.showStatus('Se necesitan al menos 2 jugadores para comenzar', 'error');
            return;
        }

        // Limpiar timer de simulación
        if (this.joinTimer) {
            clearInterval(this.joinTimer);
        }

        // RF11: Determinar primer jugador (el más joven)
        const youngestPlayer = this.players.reduce((youngest, current) => 
            current.age < youngest.age ? current : youngest
        );

        // Actualizar datos finales del juego
        const finalGameData = {
            user: this.userData,
            isAdmin: this.isAdmin,
            roomCode: this.roomData.code,
            room: {
                ...this.roomData,
                firstPlayer: youngestPlayer,
                admin: this.players.find(p => p.isAdmin),
                gameStarted: true
            },
            gameSettings: {
                rounds: 2,
                turnsPerRound: 6,
                timePerTurn: 60, // RF22
                dinosaurTypes: ['diplodocus', 'triceratops', 'trex', 'stegosaurus', 'brachiosaurus', 'parasaurolophus']
            }
        };

        sessionStorage.setItem('gameData', JSON.stringify(finalGameData));
        this.showStatus('Iniciando partida...', 'success');

        // RF17: Redirigir al tablero de juego
        setTimeout(() => {
            window.location.href = 'gameboard.html';
        }, 2000);
    }

    leaveRoom() {
        // RF7: Permitir abandonar sala antes de iniciar
        if (confirm('¿Estás seguro de que quieres abandonar la sala?')) {
            // Limpiar timer de simulación
            if (this.joinTimer) {
                clearInterval(this.joinTimer);
            }
            
            // Limpiar datos de sesión
            sessionStorage.removeItem('gameData');
            this.goBack();
        }
    }

    goBack() {
        // Volver al menú principal
        window.location.href = 'index.html';
    }

    showStatus(message, type = 'info') {
        // Mostrar notificación usando el sistema del GameManager
        if (window.gameManager && window.gameManager.showNotification) {
            window.gameManager.showNotification(message, type);
            return;
        }

        // Fallback para mostrar mensajes
        const statusElement = document.getElementById('statusMessage');
        const statusText = document.getElementById('statusText');
        
        if (statusElement && statusText) {
            statusText.textContent = message;
            statusElement.className = `alert alert-${type === 'error' ? 'danger' : type}`;
            statusElement.style.display = 'block';

            setTimeout(() => {
                if (statusElement.style.display === 'block') {
                    statusElement.style.display = 'none';
                }
            }, 5000);
        } else {
            // Último recurso - alert
            alert(message);
        }
    }
}

// Estilos adicionales para la sala de espera
const waitingRoomStyles = `
    .room-code-display {
        font-family: 'Courier New', monospace;
        font-size: 1.2em;
        font-weight: bold;
        color: #007bff;
        background: #f8f9fa;
        padding: 8px 12px;
        border-radius: 6px;
        border: 1px solid #dee2e6;
    }
    
    .players-list {
        max-height: 300px;
        overflow-y: auto;
    }
    
    .waiting-room-controls {
        margin-top: 20px;
    }
    
    .status-message {
        margin-top: 15px;
    }
`;

// Inyectar estilos
if (!document.querySelector('#waiting-room-styles')) {
    const styleElement = document.createElement('style');
    styleElement.id = 'waiting-room-styles';
    styleElement.textContent = waitingRoomStyles;
    document.head.appendChild(styleElement);
}

// Inicializar cuando la página cargue
document.addEventListener('DOMContentLoaded', () => {
    console.log('Inicializando Sala de Espera...');
    window.waitingRoom = new WaitingRoom();
});

// Funciones globales para compatibilidad
function createRoom() { 
    if (window.waitingRoom) window.waitingRoom.createRoom(); 
}

function startGame() { 
    if (window.waitingRoom) window.waitingRoom.startGame(); 
}

function goBack() { 
    if (window.waitingRoom) window.waitingRoom.goBack(); 
}

function leaveRoom() { 
    if (window.waitingRoom) window.waitingRoom.leaveRoom(); 
}